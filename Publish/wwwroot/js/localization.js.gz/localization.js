window.setDocumentLang = function (lang, dir) {
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('dir', dir);
};
